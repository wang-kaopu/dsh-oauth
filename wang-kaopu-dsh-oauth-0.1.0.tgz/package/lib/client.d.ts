export interface OAuthStatus {
    codex: {
        authenticated: boolean;
    };
    gemini: {
        authenticated: boolean;
    };
}
export interface OAuthBridgeClient {
    status(): Promise<OAuthStatus>;
    login(provider: 'codex' | 'gemini'): Promise<void>;
    logout(provider: 'codex' | 'gemini'): Promise<void>;
}
export declare const inject: readonly ["slots"];
interface ClientContext {
    slots: {
        inject(name: string, register: () => unknown): unknown;
        register(options: Record<string, unknown>, component: unknown): unknown;
    };
}
/**
 * Create the browser-side client for the loopback OAuth control server.
 *
 * @param baseUrl - loopback control server URL.
 * @returns status, login, and logout operations.
 */
export declare function createOAuthBridgeClient(baseUrl?: string): OAuthBridgeClient;
/**
 * Register the OAuth panel in the DSH Web settings surface.
 *
 * @param ctx - DSH client context providing the settings slot registry.
 */
export declare function apply(ctx: ClientContext): void;
/**
 * Render the intentionally small OAuth provider status panel.
 *
 * @param container - DOM node that receives the panel.
 * @param client - loopback control client.
 */
export declare function renderOAuthProviders(container: HTMLElement, client?: OAuthBridgeClient): Promise<void>;
export {};
//# sourceMappingURL=client.d.ts.map